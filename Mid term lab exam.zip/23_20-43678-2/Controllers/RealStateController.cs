﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Real_State_Management_System.DTO;
using Real_State_Management_System;
using Real_State_Management_System.EF;
using Real_State_Management_System.Auth;


namespace Real_State_Management_System.Controllers
{
    public class RealStateController : Controller
    {
        RSMSEntities1 db = new RSMSEntities1();

        public static Property Convert(PropertiesDTO d)
        {
            return new Property
            {
                Id = d.Id,
                Location = d.Location,
                Price = d.Price,
                Status = d.Status

            };
        }
        public static PropertiesDTO Convert (Property d)
        {
            return new PropertiesDTO
            {
                Id = d.Id,
                Location = d.Location,
                Price = d.Price,
                Status = d.Status
            };
      
        }

        public static List<PropertiesDTO> Convert(List<Property> data)
        {
            var list = new List<PropertiesDTO>();
            foreach (var d in data)
            {
                list.Add(Convert(d));
            }
            return list;
        }


        [AllowAnonymous]
        public ActionResult List()
        {
            var data = db.Properties.ToList();
            return View(Convert(data));
        }


        [HttpGet]
        public ActionResult Create()
        {
            return View(new Property());
        }
        [HttpPost]
        public ActionResult Create(PropertiesDTO d)
        {
            if (ModelState.IsValid)
            {
                db.Properties.Add(Convert(d));
                db.SaveChanges();
                TempData["msg"] = "Create Successfully";
                return RedirectToAction("List");
            }
            return View(d);
        }

        [AdminAccess]
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var exobj = db.Properties.Find(id);
            return View(Convert(exobj));
        }

        [HttpPost]
        public ActionResult Edit(PropertiesDTO d)
        {
            var exobj = db.Properties.Find(d.Id);
            db.Entry(exobj).CurrentValues.SetValues(d);
            db.SaveChanges();
            TempData["msg"] = "Edit Successfully";
            return RedirectToAction("List");
        }


        [AdminAccess]
        [HttpGet]
        public ActionResult Delete(int Id)
        {
            var exobj = db.Properties.Find(Id);
            return View(Convert(exobj));
        }
        [HttpPost]
        public ActionResult Delete(int Id, string dcsn)
        {
            if (dcsn.Equals("yes"))
            {
                var exobj = db.Properties.Find(Id);
                db.Properties.Remove(exobj);
                db.SaveChanges();
                TempData["msg"] = "Delete Successfully";
            }
            return RedirectToAction("List");
        }
    }

}
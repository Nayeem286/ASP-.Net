﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Real_State_Management_System.DTO;
using Real_State_Management_System;
using Real_State_Management_System.EF;

namespace Real_State_Management_System.Controllers
{
    public class LoginController : Controller
    {
        RSMSEntities1 db = new RSMSEntities1();


        [HttpGet]
        public ActionResult Index()
        {
            return View(new LoginDTO());
        }
        [HttpPost]
        public ActionResult Index(LoginDTO log)
        {
            if (ModelState.IsValid)
            {
                var user = (from u in db.Users
                            where u.Name == log.Name
                            && u.Password == log.Password && u.Email == log.Email
                            select u).SingleOrDefault();
                if (user != null)
                {
                    Session["user"] = user;
                    return RedirectToAction("List", "RealState");
                }

            }
            return View(log);
        }
    }
}
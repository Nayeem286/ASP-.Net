﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Real_State_Management_System.DTO
{
    public class PropertiesDTO
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Location is required.")]
        [StringLength(50, ErrorMessage = "Location must be at most 100 characters long.")]
        public string Location { get; set; }

        [Required(ErrorMessage = "Price is required.")]
        [Range(0, int.MaxValue, ErrorMessage = "Price must be a positive value.")]
        public int Price { get; set; }


        [Required(ErrorMessage = "Status is required.")]
        [StringLength(50, ErrorMessage = "Status must be at most 50 characters long.")]
        public string Status { get; set; }
    }
}